#!/bin/bash

for a in 2 3 5; do for b in 0.000005 0.0005 0.05; do for c in 0.3 0.6 0.8 0.9; do MetaCurator.py -i TestSet_25kPerMarker_v2.fa -it TestSet.tax -r ITS2_${a}Reps.fa -e ${b} -t 5 -cs 1.0,0.975,0.95,${c} -is 2,2,2,3 -of ITS2_${b}eval_${a}reps_${c}cov.fa -ot ITS2_${b}eval_${a}reps_${c}cov.tax 2> ITS2_${b}eval_${a}reps_${c}cov_log.txt; done; done; done
